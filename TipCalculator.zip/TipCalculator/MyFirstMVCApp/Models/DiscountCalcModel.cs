﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DiscountCalculator.Models
{
    public class DiscountCalcModel
    {
        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter a value bigger than {1}")]
        public decimal MealCost { get; set; }


        public decimal Calculate15pTip()
        {
            return MealCost * 15 / 100;
        }

        public decimal Calculate20pTip()
        {
            return MealCost * 20 / 100;
        }

        public decimal Calculate25pTip()
        {
            return MealCost * 25 / 100;
        }
    }
}