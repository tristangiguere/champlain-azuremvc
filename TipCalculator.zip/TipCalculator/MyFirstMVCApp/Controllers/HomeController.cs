﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DiscountCalculator.Models;
using Microsoft.AspNetCore.Mvc;

namespace DiscountCalculator.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.FifteenPercentTip = 0.00;
            ViewBag.TwentyPercentTip = 0.00;
            ViewBag.TwentyFivePercentTip = 0.00;
            ViewBag.Total = 0.00;
            return View();
        }

        [HttpPost]
        public IActionResult Index(DiscountCalcModel model)
        {

                ViewBag.FifteenPercentTip = model.Calculate15pTip();
                ViewBag.TwentyPercentTip = model.Calculate20pTip();
                ViewBag.TwentyFivePercentTip = model.Calculate25pTip();
            
            return View(model);
        }
    }
}


