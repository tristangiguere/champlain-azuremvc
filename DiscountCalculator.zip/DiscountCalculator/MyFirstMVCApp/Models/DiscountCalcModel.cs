﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DiscountCalculator.Models
{
    public class DiscountCalcModel
    {
        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter a value bigger than {1}")]
        public decimal Subtotal { get; set; }

        [Required]
        [Range(0, 100)]
        public decimal DiscountPercent { get; set; }

        public decimal CalculateDiscountAmount()
        {
            return (DiscountPercent / 100) * Subtotal;
        }

        public decimal CalculateTotal()
        {
            return Subtotal - CalculateDiscountAmount();
        }
    }
}