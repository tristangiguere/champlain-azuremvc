﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DiscountCalculator.Models;
using Microsoft.AspNetCore.Mvc;

namespace DiscountCalculator.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.DiscountAmt = 0.00;
            ViewBag.Total = 0.00;
            return View();
        }

        [HttpPost]
        public IActionResult Index(DiscountCalcModel model)
        {
            //if (ModelState.IsValid)
            //{
                ViewBag.DiscountAmt = model.CalculateDiscountAmount();
                ViewBag.Total = model.CalculateTotal();
            //}
            
            return View(model);
        }
    }
}


